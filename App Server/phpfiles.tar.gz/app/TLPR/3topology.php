<html>
<head>
<title>3 Topology</title>
</head>
<frameset rows = "30%,*">
   <frame name = "top" src ="3top/top.php" noresize="noresize">
   <frameset cols = "33%,33%,*%" noresize="noresize">
      <frameset rows = "10%,*" frameborder="no" noresize="noresize">
         <frame name = "left-1" src = "3top/left.php">
         <frame name = "left" src = "http://10.80.9.2/app/jpg/topology1.jpg">
      </frameset>
      <frameset rows = "10%,*" frameborder="no" noresize="noresize">
         <frame name = "center-1" src = "3top/center.php">
         <frame name = "center" src = "http://10.80.9.2/app/jpg/topology2.jpg">
      </frameset>
      <frameset rows = "10%,*" frameborder="no" noresize="noresize">
         <frame name = "right-1" src = "3top/right.php">
         <frame name = "right" src = "http://10.80.9.2/app/jpg/topology3.jpg">
      </frameset>
    </frameset>
    <noframes>
       <body>Your browser does not support frames.</body>
    </noframes>
</frameset>
</html>
