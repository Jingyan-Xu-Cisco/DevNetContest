<html>
<body>
<head>
<style>
h4 {
  font-size: 0.675em; /* 30px/16=1.875em */
}
</style>
</head>
<a href="http://10.80.9.3/TLPR" target="_parent"><img src="/app/jpg/tlpr-text.gif"></a>
<h1>Display topology for last 3 time windows </h1>
<h4>PHP Version : <?php echo  phpversion() ?></h4>

</html>
