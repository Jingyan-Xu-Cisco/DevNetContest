<html>
<h1>Hello! This program is to generate current topology</h1><br>
<?php

header('Location: http://10.80.9.2/app/TLPR/generate.php');

?>
</html>
