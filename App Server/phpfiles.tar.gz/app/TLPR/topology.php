<html>
<body>
<head>
<style>
h4 {
  font-size: 0.675em; /* 30px/16=1.875em */
}
</style>
</head>
<a href="http://10.80.9.3/TLPR"><img src="/app/jpg/tlpr-text.gif"></a>
<?php
echo '<h1>Current Topology</h1>';
echo '<h4>PHP version: ' . phpversion();
echo '</h4><hr><br>';
echo '<img src="/app/jpg/topology.jpg" border=0 style="border:0; text-decoration:none; outline:none">'
?>
</body>
</html>
